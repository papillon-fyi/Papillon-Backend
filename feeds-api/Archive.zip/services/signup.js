const AWS = require("aws-sdk");
AWS.config.update({
  region: "us-east-1",
});
const util = require("../utils/util");
const bcrypt = require("bcryptjs");
const auth = require("../utils/auth");

const dynamodb = new AWS.DynamoDB.DocumentClient();
const accountsTable = "wuvu-accounts";

const defaults = require("./defaults");
const defaultwardrobe = defaults.WARDROBE;

const signup = async (accountInfo) => {
  const id = Date.now();
  const email = accountInfo.email;
  const password = accountInfo.password;

  if (!email || !password) {
    return util.buildResponse(401, {
      message: "Please enter a valid email and password.",
    });
  }

  const dynamoAccount = await getAccount(email.toLowerCase().trim());
  if (dynamoAccount && dynamoAccount.email) {
    return util.buildResponse(401, {
      message: "This email/username has already been taken.",
    });
  }

  const encryptedPassword = bcrypt.hashSync(password.trim(), 10);
  const passcode = Math.random().toString(36).slice(2, 8);

  const account = {
    id: id,
    email: email,
    username: `user${id}`,
    password: encryptedPassword,
    image: "",
    bio: "",
    characteristics: {},
    location: {},
    subscription: "free",
    outfits: {},
    credits: 10,
    wardrobe: defaultwardrobe,
    pushtokens: [],
    newaccount: true,
    onboarded: false,
    lastactive: 0,
    calendar: {},
    shop: {},
  };

  const putAccountResponse = await putAccount(account);
  if (!putAccountResponse) {
    return util.buildResponse(503, { message: "Server error!" });
  }

  const token = auth.generateToken({
    id: id,
    email: email,
    username: `user${id}`,
    image: "",
    bio: "",
    characteristics: {},
    location: {},
    subscription: "free",
    outfits: {},
    credits: 0,
    wardrobe: defaultwardrobe,
    pushtokens: [],
    newaccount: true,
    onboarded: false,
    lastactive: 0,
    calendar: {},
    shop: {},
  });

  const response = {
    account: {
      id: id,
      email: email,
      username: `user${id}`,
      image: "",
      bio: "",
      characteristics: {},
      location: {},
      subscription: "free",
      outfits: {},
      credits: 0,
      wardrobe: defaultwardrobe,
      pushtokens: [],
      newaccount: true,
      onboarded: false,
      lastactive: 0,
      calendar: {},
      shop: {},
    },
    token: token,
  };
  return util.buildResponse(200, response);
};

const getAccount = async (identifier) => {
  const emailparams = {
    TableName: accountsTable,
    IndexName: "email-index",
    KeyConditionExpression: "email = :email",
    ExpressionAttributeValues: {
      ":email": identifier,
    },
  };

  const usernameparams = {
    TableName: accountsTable,
    IndexName: "username-index",
    KeyConditionExpression: "username = :username",
    ExpressionAttributeValues: {
      ":username": identifier,
    },
  };

  try {
    let emaildata = await dynamodb.query(emailparams).promise();
    let usernamedata = await dynamodb.query(usernameparams).promise();
    return emaildata.Items[0] || usernamedata.Items[0];
  } catch (error) {
    return error;
  }
};

const putAccount = async (account) => {
  const params = {
    TableName: accountsTable,
    Item: account,
  };
  return await dynamodb
    .put(params)
    .promise()
    .then(
      () => {
        return true;
      },
      (error) => {
        console.error("Error putting account: ", error);
      }
    );
};

module.exports.signup = signup;
