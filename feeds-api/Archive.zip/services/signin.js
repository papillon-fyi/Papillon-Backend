const AWS = require("aws-sdk");
AWS.config.update({
  region: "us-east-1",
});
const util = require("../utils/util");
const bcrypt = require("bcryptjs");
const auth = require("../utils/auth");

const dynamodb = new AWS.DynamoDB.DocumentClient();
const accountsTable = "wuvu-accounts";

const defaults = require("./defaults");
const defaultwardrobe = defaults.WARDROBE;

const signin = async (account) => {
  const identifier = account.identifier;
  const password = account.password;
  const federated = account.federated;
  const weblogin = account.weblogin;

  if (!account || ((!identifier || !password) && !federated)) {
    return util.buildResponse(401, {
      message:
        "Please enter a valid email/username and password, or federated authentication.",
    });
  }

  let dynamoAccount = await getAccount(identifier);

  if (federated && !dynamoAccount && weblogin === true) {
    return util.buildResponse(401, {
      message:
        "You will need to first create an account on the Wuvu app before signing in here.",
    });
  }

  if (federated && !dynamoAccount) {
    const id = Date.now();
    const account = {
      id: id,
      email: identifier,
      username: `user${id}`,
      password: null,
      image: "",
      bio: "",
      characteristics: {},
      location: {},
      subscription: "free",
      outfits: {},
      credits: 10,
      wardrobe: defaultwardrobe,
      pushtokens: [],
      newaccount: true,
      onboarded: false,
      lastactive: 0,
      calendar: {},
      shop: {},
    };

    const putAccountResponse = await putAccount(account);
    if (!putAccountResponse) {
      return util.buildResponse(503, { message: "Server error!" });
    }
  }
  dynamoAccount = await getAccount(identifier);

  if (!dynamoAccount) {
    return util.buildResponse(403, { message: "Invalid email/username." });
  }

  let response = null;

  if (federated || bcrypt.compareSync(password, dynamoAccount.password)) {
    const accountInfo = {
      id: dynamoAccount.id,
      email: dynamoAccount.email,
      username: dynamoAccount.username,
      image: dynamoAccount.image,
      password: dynamoAccount.password,
      bio: dynamoAccount.bio,
      characteristics: dynamoAccount.characteristics,
      location: dynamoAccount.location,
      subscription: dynamoAccount.subscription,
      outfits: dynamoAccount.outfits,
      credits: dynamoAccount.credits,
      wardrobe: dynamoAccount.wardrobe,
      pushtokens: dynamoAccount.pushtokens,
      newaccount: dynamoAccount.newaccount,
      onboarded: dynamoAccount.onboarded,
      lastactive: dynamoAccount.lastactive,
      calendar: dynamoAccount.calendar,
      shop: dynamoAccount.shop,
    };

    const token = auth.generateToken(accountInfo);
    response = {
      account: accountInfo,
      token: token,
    };
  }

  if (!!response) {
    return util.buildResponse(200, response);
  } else {
    return util.buildResponse(403, {
      message:
        "Invalid email/username or password. Please make sure that you have an account and try again.",
    });
  }
};

const getAccount = async (identifier) => {
  const emailparams = {
    TableName: accountsTable,
    IndexName: "email-index",
    KeyConditionExpression: "email = :email",
    ExpressionAttributeValues: {
      ":email": identifier,
    },
  };

  const usernameparams = {
    TableName: accountsTable,
    IndexName: "username-index",
    KeyConditionExpression: "username = :username",
    ExpressionAttributeValues: {
      ":username": identifier,
    },
  };

  try {
    let emaildata = await dynamodb.query(emailparams).promise();
    let usernamedata = await dynamodb.query(usernameparams).promise();
    return emaildata.Items[0] || usernamedata.Items[0];
  } catch (error) {
    return error;
  }
};

const putAccount = async (account) => {
  const params = {
    TableName: accountsTable,
    Item: account,
  };
  return await dynamodb
    .put(params)
    .promise()
    .then(
      () => {
        return true;
      },
      (error) => {
        console.error("Error putting account: ", error);
      }
    );
};

module.exports.signin = signin;
