const AWS = require("aws-sdk");
AWS.config.update({
  region: "us-east-1",
});
const util = require("../utils/util");
const bcrypt = require("bcryptjs");
const dynamodb = new AWS.DynamoDB.DocumentClient();
const accountsTable = "wuvu-accounts";

const get = async (key, usingId) => {
  if (!!key) {
    if (usingId) {
      const params = {
        TableName: accountsTable,
        Key: {
          id: Number(key),
        },
      };

      return await dynamodb
        .get(params)
        .promise()
        .then(
          (response) => {
            return util.buildResponse(200, response.Item);
          },
          (error) => {
            console.error("Error getting account: ", error);
            return error;
          }
        );
    } else {
      const emailparams = {
        TableName: accountsTable,
        IndexName: "email-index",
        KeyConditionExpression: "email = :email",
        ExpressionAttributeValues: {
          ":email": key,
        },
      };

      const usernameparams = {
        TableName: accountsTable,
        IndexName: "username-index",
        KeyConditionExpression: "username = :username",
        ExpressionAttributeValues: {
          ":username": key,
        },
      };

      try {
        let emaildata = await dynamodb.query(emailparams).promise();
        let usernamedata = await dynamodb.query(usernameparams).promise();
        return util.buildResponse(
          200,
          emaildata.Items[0] || usernamedata.Items[0]
        );
      } catch (error) {
        return error;
      }
    }
  } else {
    const params = {
      TableName: accountsTable,
    };
    return await dynamodb
      .scan(params)
      .promise()
      .then(
        (response) => {
          return util.buildResponse(200, response);
        },
        (error) => {
          console.error("Error getting accounts: ", error);
          return error;
        }
      );
  }
};

const post = async (accountInfo, accountId) => {
  const email = accountInfo.email;
  const username = accountInfo.username;
  const password = accountInfo.password;
  const image = accountInfo.image;
  const bio = accountInfo.bio;
  const characteristics = accountInfo.characteristics;
  const location = accountInfo.location;
  const subscription = accountInfo.subscription;
  const outfits = accountInfo.outfits;
  const credits = accountInfo.credits;
  const wardrobe = accountInfo.wardrobe;
  const pushtokens = accountInfo.pushtokens;
  const newaccount = accountInfo.newaccount;
  const onboarded = accountInfo.onboarded;
  const lastactive = accountInfo.lastactive;
  const calendar = accountInfo.calendar;
  const shop = accountInfo.shop;

  const deleting = accountInfo.deleting;
  const oldpassword = accountInfo.oldpassword;
  const deleteavatarimage = accountInfo.deleteavatarimage;
  const deleteclothesimage = accountInfo.deleteclothesimage;
  const changepassword = accountInfo.changepassword;

  const dynamoAccount = await getAccount(accountId, true);

  if (deleting) {
    const putAccountResponse = await deleteAccount(accountId);
    console.log(putAccountResponse);
    if (!putAccountResponse) {
      return util.buildResponse(503, { message: "Server error!" });
    } else {
      return util.buildResponse(200);
    }
  }

  if (!!deleteavatarimage) {
    var s3 = new AWS.S3({ apiVersion: "2006-03-01" });
    var params = {
      Bucket: "wuvu-avatars",
      Key: deleteavatarimage,
    };
    s3.deleteObject(params, function (err, data) {
      if (err) console.log(err, err.stack);
      else console.log(data);
    });
  }

  if (!!deleteclothesimage) {
    var s3 = new AWS.S3({ apiVersion: "2006-03-01" });
    var params = {
      Bucket: "wuvu-clothes",
      Key: deleteclothesimage,
    };
    s3.deleteObject(params, function (err, data) {
      if (err) console.log(err, err.stack);
      else console.log(data);
    });
  }

  const encryptedPassword = !!password
    ? bcrypt.hashSync(password.trim(), 10)
    : null;

  const account = {
    id: dynamoAccount.id,
    email: !!email ? email.toLowerCase().trim() : dynamoAccount.email,
    username: !!username
      ? username.toLowerCase().trim()
      : dynamoAccount.username,
    password: !!password ? encryptedPassword : dynamoAccount.password,
    image: !!image ? image : dynamoAccount.image,
    bio: !!bio ? bio.trim() : dynamoAccount.bio,
    characteristics: !!characteristics
      ? characteristics
      : dynamoAccount.characteristics,
    location: !!location ? location : dynamoAccount.location,
    subscription: !!subscription
      ? subscription.trim()
      : dynamoAccount.subscription,
    outfits: !!outfits ? outfits : dynamoAccount.outfits,
    credits:
      credits !== null && credits !== undefined
        ? credits
        : dynamoAccount.credits,
    wardrobe: !!wardrobe ? wardrobe : dynamoAccount.wardrobe,
    pushtokens: !!pushtokens ? pushtokens : dynamoAccount.pushtokens,
    newaccount:
      newaccount !== null && newaccount !== undefined
        ? newaccount
        : dynamoAccount.newaccount,
    onboarded: !!onboarded ? onboarded : dynamoAccount.onboarded,
    lastactive: !!lastactive ? lastactive : dynamoAccount.lastactive,
    calendar: !!calendar ? calendar : dynamoAccount.calendar,
    shop: !!shop ? shop : dynamoAccount.shop,
    changepassword: !!changepassword
      ? changepassword
      : dynamoAccount.changepassword,
  };

  if (!!changepassword) {
    if (oldpassword === null || oldpassword === undefined) {
      account.password = bcrypt.hashSync(password.trim(), 10);
    } else if (bcrypt.compareSync(oldpassword, dynamoAccount.password)) {
      account.password = bcrypt.hashSync(password.trim(), 10);
      account.initialsession = false;
    } else {
      return util.buildResponse(403, {
        message: "Incorrect entry for current password.",
      });
    }
  }

  const putAccountResponse = await putAccount(account);
  if (!putAccountResponse) {
    return util.buildResponse(503, { message: "Server error!" });
  }

  const response = {
    account: account,
  };
  return util.buildResponse(200, response);
};

const dynamicget = async (key) => {
  const params = {
    TableName: accountsTable,
    IndexName: "username-index",
    FilterExpression: "contains(username, :substring)",
    ExpressionAttributeValues: {
      ":substring": key,
    },
  };

  return await dynamodb
    .scan(params)
    .promise()
    .then(
      (response) => {
        return util.buildResponse(200, response.Items);
      },
      (error) => {
        console.error("Error getting accounts: ", error);
        return error;
      }
    );
};

const getAccount = async (key, usingId) => {
  if (usingId) {
    const params = {
      TableName: accountsTable,
      Key: {
        id: Number(key),
      },
    };

    return await dynamodb
      .get(params)
      .promise()
      .then(
        (response) => {
          return response.Item;
        },
        (error) => {
          console.error("Error getting account: ", error);
        }
      );
  } else {
    const emailparams = {
      TableName: accountsTable,
      IndexName: "email-index",
      KeyConditionExpression: "email = :email",
      ExpressionAttributeValues: {
        ":email": key,
      },
    };

    const usernameparams = {
      TableName: accountsTable,
      IndexName: "username-index",
      KeyConditionExpression: "username = :username",
      ExpressionAttributeValues: {
        ":username": key,
      },
    };

    try {
      let emaildata = await dynamodb.query(emailparams).promise();
      let usernamedata = await dynamodb.query(usernameparams).promise();
      return emaildata.Items[0] || usernamedata.Items[0];
    } catch (error) {
      return error;
    }
  }
};

const putAccount = async (account) => {
  const params = {
    TableName: accountsTable,
    Item: account,
  };
  return await dynamodb
    .put(params)
    .promise()
    .then(
      () => {
        return true;
      },
      (error) => {
        console.error("Error putting account: ", error);
      }
    );
};

const deleteAccount = async (key) => {
  const params = {
    TableName: accountsTable,
    Key: {
      id: Number(key),
    },
  };
  await dynamodb.delete(params).promise().catch(console.error);

  return true;
};

module.exports.get = get;
module.exports.post = post;
module.exports.dynamicget = dynamicget;
