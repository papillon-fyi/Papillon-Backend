const timestamp = Date.now();
const defaultwardrobe = {
  [timestamp + 1]: {
    id: timestamp + 1,
    title: "White dress shirt",
    image: "https://wuvu-defaults.s3.amazonaws.com/white_dress_shirt.png",
    type: "tops",
  },
  [timestamp + 2]: {
    id: timestamp + 2,
    title: "Red jersey",
    image: "https://wuvu-defaults.s3.amazonaws.com/red_jersey.png",
    type: "tops",
  },
  [timestamp + 3]: {
    id: timestamp + 3,
    title: "Green turtleneck",
    image: "https://wuvu-defaults.s3.amazonaws.com/green_turtleneck.png",
    type: "tops",
  },
  [timestamp + 4]: {
    id: timestamp + 4,
    title: "Orange graphic tee",
    image: "https://wuvu-defaults.s3.amazonaws.com/orange_graphic_tee.png",
    type: "tops",
  },
  [timestamp + 5]: {
    id: timestamp + 5,
    title: "Blue jeans",
    image: "https://wuvu-defaults.s3.amazonaws.com/blue_jeans.png",
    type: "bottoms",
  },
  [timestamp + 6]: {
    id: timestamp + 6,
    title: "Black dress slacks",
    image: "https://wuvu-defaults.s3.amazonaws.com/black_dress_slacks.png",
    type: "bottoms",
  },
  [timestamp + 7]: {
    id: timestamp + 7,
    title: "Beige shorts",
    image: "https://wuvu-defaults.s3.amazonaws.com/beige_shorts.png",
    type: "bottoms",
  },
  [timestamp + 8]: {
    id: timestamp + 8,
    title: "Gray sweatpants",
    image: "https://wuvu-defaults.s3.amazonaws.com/gray_sweatpants.png",
    type: "bottoms",
  },
  [timestamp + 9]: {
    id: timestamp + 9,
    title: "White sneakers",
    image: "https://wuvu-defaults.s3.amazonaws.com/white_sneakers.png",
    type: "footwear",
  },
  [timestamp + 10]: {
    id: timestamp + 10,
    title: "Black loafers",
    image: "https://wuvu-defaults.s3.amazonaws.com/black_loafers.png",
    type: "footwear",
  },
  [timestamp + 11]: {
    id: timestamp + 11,
    title: "Brown boots",
    image: "https://wuvu-defaults.s3.amazonaws.com/brown_boots.png",
    type: "footwear",
  },
  [timestamp + 12]: {
    id: timestamp + 12,
    title: "Tan sandals",
    image: "https://wuvu-defaults.s3.amazonaws.com/tan_sandals.png",
    type: "footwear",
  },
  [timestamp + 13]: {
    id: timestamp + 13,
    title: "Yellow bomber jacket",
    image: "https://wuvu-defaults.s3.amazonaws.com/yellow_bomber_jacket.png",
    type: "outerwear",
  },
  [timestamp + 14]: {
    id: timestamp + 14,
    title: "Pink hoodie",
    image: "https://wuvu-defaults.s3.amazonaws.com/pink_hoodie.png",
    type: "outerwear",
  },
  [timestamp + 15]: {
    id: timestamp + 15,
    title: "Black tuxedo jacket",
    image: "https://wuvu-defaults.s3.amazonaws.com/black_tuxedo_jacket.png",
    type: "outerwear",
  },
  [timestamp + 16]: {
    id: timestamp + 16,
    title: "Gray parka",
    image: "https://wuvu-defaults.s3.amazonaws.com/gray_parka.png",
    type: "outerwear",
  },
  [timestamp + 17]: {
    id: timestamp + 17,
    title: "Maroon beret",
    image: "https://wuvu-defaults.s3.amazonaws.com/maroon_beret.png",
    type: "headwear",
  },
  [timestamp + 18]: {
    id: timestamp + 18,
    title: "Navy baseball cap",
    image: "https://wuvu-defaults.s3.amazonaws.com/navy_baseball_cap.png",
    type: "headwear",
  },
  [timestamp + 19]: {
    id: timestamp + 19,
    title: "Nova check scarf",
    image: "https://wuvu-defaults.s3.amazonaws.com/nova_check_scarf.png",
    type: "headwear",
  },
  [timestamp + 20]: {
    id: timestamp + 20,
    title: "Olive beanie",
    image: "https://wuvu-defaults.s3.amazonaws.com/olive_beanie.png",
    type: "headwear",
  },
  [timestamp + 21]: {
    id: timestamp + 21,
    title: "Digital watch",
    image: "https://wuvu-defaults.s3.amazonaws.com/digital_watch.png",
    type: "accessories",
  },
  [timestamp + 22]: {
    id: timestamp + 22,
    title: "Analog Watch",
    image: "https://wuvu-defaults.s3.amazonaws.com/analog_watch.png",
    type: "accessories",
  },
  [timestamp + 23]: {
    id: timestamp + 23,
    title: "Wooden bracelet",
    image: "https://wuvu-defaults.s3.amazonaws.com/wooden_bracelet.png",
    type: "accessories",
  },
  [timestamp + 24]: {
    id: timestamp + 24,
    title: "Gold necklace",
    image: "https://wuvu-defaults.s3.amazonaws.com/gold_necklace.png",
    type: "accessories",
  },
};

module.exports = Object.freeze({
  WARDROBE: defaultwardrobe,
});
