const util = require("../utils/util");
const auth = require("../utils/auth");

const verify = (requestBody) => {
  if (!requestBody.account || !requestBody.account.id || !requestBody.token) {
    return util.buildResponse(401, {
      verified: false,
      message: "Incorrenct request body.",
    });
  }

  const account = requestBody.account;
  const token = requestBody.token;
  const verification = auth.verifyToken(account.id, token);
  if (!verification.verified) {
    return util.buildResponse(401, verification);
  }

  return util.buildResponse(200, {
    verified: true,
    message: "Success.",
    account: account,
    token: token,
  });
};

module.exports.verify = verify;
