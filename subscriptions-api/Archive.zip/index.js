const subscriptionsService = require("./services/subscriptions");
const util = require("./utils/util");

const healthPath = "/health";
const plansPath = "/plans";
const checkoutPath = "/checkout";

exports.handler = async (event) => {
  let response;
  switch (true) {
    case event.httpMethod === "GET" && event.path === healthPath:
      response = util.buildResponse(200);
      break;
    case event.httpMethod === "GET" && event.path.slice(0, 6) === plansPath:
      response = await subscriptionsService.get(event.path.slice(7));
      break;
    case event.httpMethod === "POST" && event.path === checkoutPath:
      const checkoutBody = JSON.parse(event.body);
      response = await subscriptionsService.checkout(checkoutBody);
      break;
    default:
      response = util.buildResponse(404, "404 not found");
  }
  return response;
};
