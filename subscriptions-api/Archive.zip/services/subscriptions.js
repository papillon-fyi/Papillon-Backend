const AWS = require("aws-sdk");
AWS.config.update({
  region: "us-east-1",
});
const util = require("../utils/util");
const dynamodb = new AWS.DynamoDB.DocumentClient();
const subscriptionsTable = "wuvu-subscriptions";
const accountsTable = "wuvu-accounts";

const get = async (key) => {
  if (!!key) {
    const params = {
      TableName: subscriptionsTable,
      Key: {
        id: key,
      },
    };

    return await dynamodb
      .get(params)
      .promise()
      .then(
        (response) => {
          return util.buildResponse(200, response.Item);
        },
        (error) => {
          console.error("Error getting subscription: ", error);
          return error;
        }
      );
  } else {
    const params = {
      TableName: subscriptionTable,
    };
    return await dynamodb
      .scan(params)
      .promise()
      .then(
        (response) => {
          return util.buildResponse(200, response);
        },
        (error) => {
          console.error("Error getting subscriptions: ", error);
          return error;
        }
      );
  }
};

const checkout = async (checkoutInfo) => {
  const accountId = checkoutInfo.accountId;
  const subscription = checkoutInfo.subscription;
  const cancelling = checkoutInfo.cancelling;

  const dynamoAccount = await getAccount(accountId, true);

  const account = {
    id: dynamoAccount.id,
    email: dynamoAccount.email,
    username: dynamoAccount.username,
    password: dynamoAccount.password,
    image: dynamoAccount.image,
    bio: dynamoAccount.bio,
    characteristics: dynamoAccount.characteristics,
    location: dynamoAccount.location,
    subscription: !!cancelling ? "free" : subscription.trim(),
    outfits: dynamoAccount.outfits,
    credits:
      subscription.trim() === "pro" && !cancelling
        ? 50
        : subscription.trim() === "max" && !cancelling
        ? 1000000
        : dynamoAccount.credits,
    wardrobe: dynamoAccount.wardrobe,
    pushtokens: dynamoAccount.pushtokens,
    newaccount: dynamoAccount.newaccount,
    onboarded: dynamoAccount.onboarded,
    lastactive: dynamoAccount.lastactive,
    calendar: dynamoAccount.calendar,
    shop: dynamoAccount.shop,
  };

  const putAccountResponse = await putAccount(account);
  if (!putAccountResponse) {
    return util.buildResponse(503, { message: "Server error!" });
  }

  const response = {
    subscription: `wuvu ${subscription} ${
      cancelling ? "cancelled" : "purchased"
    }`,
    account: account,
  };
  return util.buildResponse(200, response);
};

const getAccount = async (key) => {
  const params = {
    TableName: accountsTable,
    Key: {
      id: Number(key),
    },
  };

  return await dynamodb
    .get(params)
    .promise()
    .then(
      (response) => {
        return response.Item;
      },
      (error) => {
        console.error("Error getting accounts: ", error);
      }
    );
};

const putAccount = async (account) => {
  const params = {
    TableName: accountsTable,
    Item: account,
  };
  return await dynamodb
    .put(params)
    .promise()
    .then(
      () => {
        return true;
      },
      (error) => {
        console.error("Error putting account: ", error);
      }
    );
};

module.exports.get = get;
module.exports.checkout = checkout;
